<?php

class Hierarchy_model extends CI_Model {

    public $i = -1;
    public $a = array();

    function __construct() {
    }
    function getCategoryTree($level = 'P5TFPH', $prefix = '') {
        $rows = $this->db
                ->select('referred_by as  parentId, referral_code as memberId  ,first_name,last_name,mobile_no')
                ->where('referred_by', $level)
                ->get('hierarchy')
                ->result();
        $category = '';
        if (count($rows) > 0) {
            foreach ($rows as $row) {
                // $category = '';
                $this->i = $this->i + 1;
                $this->a[$this->i]['memberId'] = $row->memberId;
                $this->a[$this->i]['parentId'] = $row->parentId;
                $this->a[$this->i]['otherInfo'] = $row->first_name . ' ' . $row->last_name . '<br>' . $row->mobile_no;
                $category .= $prefix . $row->first_name . '<br>';
                // Append subcategories
                $category .= $this->getCategoryTree($row->memberId, $prefix . '-');
            }
        }
        $aa = json_encode($this->a);
        return $aa;
    }

}

?>