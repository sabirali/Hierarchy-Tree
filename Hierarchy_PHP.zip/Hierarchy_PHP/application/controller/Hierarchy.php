<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Hierarchy extends CI_Controller {

    public function __construct() {
        parent::__construct();

        $this->load->model('Hierarchy_model');
    }

    function index() {
        $this->load->view('hierarchy_view');
    }

    function get_res() {
        $a = $this->Hierarchy_model->getCategoryTree();
        $de = json_decode($a, TRUE);
        $root_res[] = array(
            "memberId" => "P5TFPH", // referral_code
            "parentId" => "0", // referred_by
            "otherInfo" => "Ismailbhai Nodoliya 9797979701"
        );
        $final = array_merge($root_res, $de);
        echo json_encode($final);
    }

}
