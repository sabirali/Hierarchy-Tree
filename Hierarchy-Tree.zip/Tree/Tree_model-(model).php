<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tree_model extends CI_Model {

    protected $table = 'users';
    protected $id = 'user_id';
    public $order = 'DESC';
    public $start = 0;
    public $i = -1;
    public $a = array();

    function __construct() {
        parent::__construct();
    }

    function getCategoryTree($referralcode = '',$prefix = '') {
        $rows = $this->db
            ->select('first_name,last_name,mobile_no,referral_code')
            ->where('referred_by', $referralcode)
            ->order_by('user_id','asc')
            ->get('users')
            ->result();

        $category = '';
        if (count($rows) > 0) {
            
            foreach ($rows as $row) {
                $this->start = $this->start + 1;
                $category .='<tr>';
                $category .= '<td>'.$this->start.'</td>';
                $category .= '<td>'.$prefix.$row->first_name.'</td>';
                $category .= '<td>'.$row->last_name.'</td>';
                $category .= '<td>'.$row->mobile_no.'</td>';
                // Append subcategories
                $category .= $this->getCategoryTree($row->referral_code,$prefix. '=>');
                $category .='<tr>';
                
            }
        }
    return $category;
    }

    function getHierarchy($level = '', $prefix = '', $fff = 0) {
         if ($fff == 0) {
        $rows = $this->db->select('referred_by as  parentId, referral_code as memberId  ,first_name as otherInfo,mobile_no,last_name,user_type,if(expired_date >= NOW(),"1","0") as payment_status')
                ->where('referred_by', $level)
                ->get('users')
                ->result();
        
        } else {
            $rows = array();
        }
        $category = '';
        if (count($rows) > 0) {
            foreach ($rows as $row) {
                $this->i = $this->i + 1;
                $this->a[$this->i]['memberId'] = $row->memberId;
                $this->a[$this->i]['parentId'] = $row->parentId;
                //$this->a[$this->i]['otherInfo'] = $row->otherInfo . ' ' . $row->last_name . '<br>' . $row->mobile_no;
                //$category .= $prefix . $row->otherInfo . '<br>';
                //$this->a[$this->i]['otherInfo'] = '<div style="background-color:#ffffcf;color:#10494B">'.$row->otherInfo . ' ' . $row->last_name .'</div>';
                $user_type = $row->user_type;
                $payment = $row->payment_status;
                //$this->a[$this->i]['otherInfo'] = $row->otherInfo . ' ' . $row->last_name . '<br>' . $row->mobile_no;
                //$category .= $prefix . $row->otherInfo . '<br>';#ffffcf
                if($user_type == "employer"){
                    if($payment == 1){
                        $this->a[$this->i]['otherInfo'] = '<div style="background-color:#00ff00;color:#10494B">'.$row->otherInfo . ' ' . $row->last_name.'</div>';        
                    }else{
                        $this->a[$this->i]['otherInfo'] = '<div style="background-color:blue;color:#ffffff">'.$row->otherInfo . ' ' . $row->last_name.'</div>';
                    }
                }else{
                    $this->a[$this->i]['otherInfo'] = '<div style="background-color:red;color:#ffffff">'.$row->otherInfo . ' ' . $row->last_name.'</div>';    
                }
                //$category .= $prefix . $row->otherInfo . '<br>';
                // Append subcategories
                $category .= $this->getHierarchy($row->memberId, $prefix . '-',1);
            }
        }
        $aa = json_encode($this->a);
        return $aa;
    }

    function onClickrefer($level = 'P5TFPH', $prefix = '', $fff = 0) {

                if ($fff == 0) {
                    $rows = $this->db->select('referred_by as  parentId, referral_code as memberId  ,first_name as otherInfo,mobile_no,last_name,user_type,if(expired_date >= NOW(),"1","0") as payment_status')
                            ->where('referred_by', $level)
                            ->get('users')
                            ->result();
                } else {
                    $rows = array();
                }

                $category = '';
                if (count($rows) > 0) {
                    foreach ($rows as $row) {
                        // $category = '';
                        $this->i = $this->i + 1;
                        $this->a[$this->i]['memberId'] = $row->memberId;
                        $this->a[$this->i]['parentId'] = $row->parentId;
                        // Append subcategories
                        $user_type = $row->user_type;
                        $payment = $row->payment_status;
                        if($user_type == "employer"){
                            if($payment == 1){
                                $this->a[$this->i]['otherInfo'] = '<div style="background-color:#00ff00;color:#10494B">'.$row->otherInfo . ' ' . $row->last_name.'</div>';        
                            }else{
                                $this->a[$this->i]['otherInfo'] = '<div style="background-color:blue;color:#ffffff">'.$row->otherInfo . ' ' . $row->last_name.'</div>';
                            }
                        }else{
                            $this->a[$this->i]['otherInfo'] = '<div style="background-color:red;color:#ffffff">'.$row->otherInfo . ' ' . $row->last_name.'</div>';    
                        }
                        //$category .= $prefix . $row->otherInfo . '<br>';
                        // Append subcategories
                        $category .= $this->onClickrefer($row->memberId, $prefix . '-',1);
                    }
                }
                $aa = json_encode($this->a);
                return $aa;
    }


    function get_parent($clicked_referral){
        $row =  $this->db->select('concat(first_name,last_name) as name,referral_code,user_type,if(expired_date >= NOW(),"1","0") as payment_status')
                ->where('referral_code', $clicked_referral)
                ->get('users')
                ->result();
        return $row;
    }

}

/* End of file Employees_model.php */
/* Location: ./application/models/Employees_model.php */
