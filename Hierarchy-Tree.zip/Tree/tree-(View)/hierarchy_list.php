<script type='text/javascript' src="<?php echo base_url('assets/hierarchy/jquery.js') ?>"></script>
<link rel="stylesheet" href="<?php echo base_url('assets/hierarchy/jquery.orgchart.css') ?>"/>
<script src="<?php echo base_url('assets/hierarchy/jquery.orgchart.js') ?>"></script>
<div class="row">
    <div class="col-md-8 ">
        <strong>Color Indicator:</strong></br> <strong>Red</strong>-><span style="color:red;">Employee</span> , <strong>Blue</strong>-><span style="color:blue;">Employer Not active</span>, <strong>Green</strong>-><span style="color:#00ff00;">Employer active</span>
    </div>
</div>

<div  style="display: none">
    <ul id="mainContainer" class="clearfix"></ul>	
</div>
<div id="main">
</div>


<script type='text/javascript'>
    $(function () {
        var members;
        $.ajax({
            url: '<?php echo site_url('admin/Tree/hierarchy_list') ?>',
            async: false,
            success: function (data) {
                members = $.parseJSON(data)
            }
        })

        //memberId,parentId,otherInfo
        for (var i = 0; i < members.length; i++) {

            var member = members[i];

            if (i == 0) {
                $("#mainContainer").append("<li id=" + member.memberId + ">" + member.otherInfo + "</li>")
            } else {

                if ($('#pr_' + member.parentId).length <= 0) {
                    $('#' + member.parentId).append("<ul id='pr_" + member.parentId + "'><li id=" + member.memberId + ">" + member.otherInfo + "</li></ul>")
                } else {
                    $('#pr_' + member.parentId).append("<li id=" + member.memberId + ">" + member.otherInfo + "</li>")
                }

            }
        }




        $("#mainContainer").orgChart({container: $("#main"), interactive: true, fade: true, speed: 'slow'});

    });


</script>
