<div class="table-responsive">
    <table class="table table-bordered mb10 table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Mobile No</th>
                <!-- <th>Action</th> -->
            </tr></thead>
        <tbody>
            <?php
            if (!empty($tree_data)) {
                echo $tree_data;
            } else {
                echo "<tr>";
                echo "<td colspan = '10'>";
                echo "<center>";
                echo "<h3 style='color:red'> Users Hierarchy Not Found...! </h3>";
                echo "</center>";
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>