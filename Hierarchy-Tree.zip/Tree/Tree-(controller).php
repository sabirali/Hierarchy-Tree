<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tree extends MY_CController {

    protected $clicked_referral;

    function __construct() {
        parent::__construct();
        $this->load->model('admin/Tree_model');
        checkAdminLogin();
        $this->pageTitle = 'Registration Hierarchy';
        $this->heading = 'Registration Hierarchy';
        $this->breadcrumbs[] = array('title' => 'Home', 'link' => getParam('admin_url'));
    }

    public function index() {
        //$referral_code = 'P5TFPH';
        $referral_code = $this->session->userdata('referral_code');
        $tree = $this->Tree_model->getCategoryTree($referral_code);
        
        $data = array(
            'tree_data' => $tree
        );
        
        $data['view'] = 'tree_list';
        $this->heading = 'User Hierarchy';
        $this->load->view('admin/content', $data);
    }
    public function hierarchy(){ 
        $data['view'] = 'hierarchy_list';
        $this->heading = 'User Hierarchy';
        $this->load->view('admin/content',$data);
    }
    
    public function hierarchy_list() { 
        $referral_code = $this->session->userdata('referral_code');
        $name = $this->session->userdata('user_fullname_cnf');
        $user_type = $this->session->userdata('user_type');
        $expired_date = $this->session->userdata('expired_date');

        if($expired_date >= date('Y-m-d H:i:s')){
            $payment_status = 1;
        }else{
            $payment_status = 0;
        }

        if($user_type == "employer"){
            if($payment_status == 1){
                $otherInfo = '<div style="background-color:#00ff00;color:#10494B">'.$name.'</div>';        
            }else{
                $otherInfo = '<div style="background-color:blue;color:#ffffff">'.$name.'</div>';
            }
        }else{
            $otherInfo = '<div style="background-color:red;color:#ffffff">'.$name.'</div>';    
        }

        $prefix = '';
        $a = $this->Tree_model->getHierarchy($referral_code,$prefix,$fff = 0);
        $de = json_decode($a, TRUE);
        $root_res[] = array(
            "memberId" => $referral_code, // referral_code
            "parentId" => "0", // referred_by
            "otherInfo" => $otherInfo
        );
        $final = array_merge($root_res, $de);

        // for divided tree in binary structure start
        for ($i = 0; $i < count($final); $i++) {

            if ($i == 0 || $i == 1 || $i == 2) {
                $mine[] = array(
                    "memberId" => $final[$i]['memberId'],
                    "parentId" => $final[$i]['parentId'],
                    "otherInfo" => $final[$i]['otherInfo'],
                );
            } else {
                $j = $i - 1;
                $res = floor($j / 2);
                $mine[] = array(
                    "memberId" => $final[$i]['memberId'],
                    "parentId" => $final[$res]['memberId'],
                    "otherInfo" => $final[$i]['otherInfo'],
                );
            }
        }
        // End
        echo json_encode($mine);
    }

    // This is for On click re-generate sub tree start
    public function onClicktree(){
        $data['view'] = 'hierarchy_regerate';
        $data['tree_list'] = $_GET['click_referral'];
        $this->load->view('admin/content',$data);
    }
    
    public function get_res_onClick() { 
        $clicked_referral = $_POST['click_referral'];

        $a = $this->Tree_model->onClickrefer($level = $clicked_referral, $prefix = '', $fff = 0);
        $parent_detail = $this->Tree_model->get_parent($clicked_referral);
        $de = json_decode($a, TRUE);

        $user_type = $parent_detail[0]->user_type;
        $payment = $parent_detail[0]->payment_status;
        $name = $parent_detail[0]->name;
        
        if($user_type == 'employer'){
            if($payment == 1){
                $otherInf = '<div style="background-color:#00ff00;color:#10494B">'.$name.'</div>';        
            }else{
                $otherInf = '<div style="background-color:blue;color:#ffffff">'.$name.'</div>';
            }
        }else{
                $otherInf = '<div style="background-color:red;color:#ffffff">'.$name.'</div>';    
        }

        $root_res[] = array(
            "memberId" => $parent_detail[0]->referral_code, // referral_code
            "parentId" => "0", // referred_by
            "otherInfo" => $otherInf,
        );
        $final = array_merge($root_res, $de);
        for ($i = 0; $i < count($final); $i++) {

            if ($i == 0 || $i == 1 || $i == 2) {
                $mine[] = array(
                    "memberId" => $final[$i]['memberId'],
                    "parentId" => $final[$i]['parentId'],
                    "otherInfo" => $final[$i]['otherInfo'],
                );
            } else {
                $j = $i - 1;
                $res = floor($j / 2);
                $mine[] = array(
                    "memberId" => $final[$i]['memberId'],
                    "parentId" => $final[$res]['memberId'],
                    "otherInfo" => $final[$i]['otherInfo'],
                );
            }
        }
        echo json_encode($mine); 
        
    }
    // END

}

/* End of file Employees.php */
/* Location: ./application/controllers/Employees.php */